Drag and drop this file into your mods folder located in the vintagestorydata folder.
Or you could go into the game and press the ''Open mod folder'' inside the mod manager to quickly get it up!